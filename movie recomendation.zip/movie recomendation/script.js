// User Management System
let currentUser = null;


const GEMINI_API_KEY = 'your-gemini-api-key'; // <-- Replace with your Gemini API key
const OMDB_API_KEY = 'your-omdb-api-key';     // <-- Replace with your OMDb API key

// Enhanced Authentication Functions
function showSignup() {
    document.getElementById('login-form').classList.remove('active');
    document.getElementById('signup-form').classList.add('active');
    clearAuthForms();
}

function showLogin() {
    document.getElementById('signup-form').classList.remove('active');
    document.getElementById('login-form').classList.add('active');
    clearAuthForms();
}

function clearAuthForms() {
    document.getElementById('signup-username').value = '';
    document.getElementById('signup-password').value = '';
    document.getElementById('signup-confirm-password').value = '';
    document.getElementById('login-username').value = '';
    document.getElementById('login-password').value = '';
}

// Enhanced Error Handling
function handleError(error) {
    console.error('Error:', error);
    const resultsDiv = document.getElementById('results');
    resultsDiv.innerHTML = `
        ⚠️ Error: ${error.message || 'Failed to fetch movie data'}
        <br>Please try again with different input
    `;
}

// Fetch New Movie Data from OMDb API
async function fetchNewMovies(query) {
    const url = `${OMDB_BASE_URL}?apikey=${OMDB_API_KEY}&s=${encodeURIComponent(query)}&type=movie`;

    try {
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`Failed to fetch data from OMDb API. Status: ${response.status}`);
        }

        const data = await response.json();
        if (data.Response === 'False') {
            throw new Error(data.Error || 'No movies found');
        }

        return data.Search || [];
    } catch (error) {
        console.error('Error fetching movie data:', error);
        throw error;
    }
}

// Improved Movie Recommendation Function
async function getRecommendations() {
    const userInput = document.getElementById('user-input').value.trim();
    const resultsDiv = document.getElementById('results');
    const loader = document.getElementById('loader');
    const category = document.querySelector('input[name="language"]:checked')?.value || '';

    if (!userInput) {
        alert('Please describe your preferences first!');
        return;
    }

    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_API_KEY}`;
    const prompt = `
Suggest 5 ${category ? category + ' ' : ''}movies for a user who likes: ${userInput}. For each movie, provide:
- Movie name
- Trailer link (YouTube, direct link)
Respond in JSON array format like:
[
  {
    "name": "Movie Title",
    "trailer": "https://youtube.com/..."
  }
]
`;

    let attempts = 0;
    const maxAttempts = 3;
    let lastError = null;

    try {
        loader.style.display = 'block';
        resultsDiv.innerHTML = '';

        while (attempts < maxAttempts) {
            attempts++;
            try {
                const response = await fetch(url, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        contents: [{ parts: [{ text: prompt }] }]
                    })
                });

                const data = await response.json();

                if (!response.ok) {
                    if (data.error?.message && data.error.message.toLowerCase().includes('overloaded')) {
                        await new Promise(res => setTimeout(res, 1500 * attempts));
                        continue;
                    }
                    throw new Error(data.error?.message || 'API error');
                }

                const text = data.candidates?.[0]?.content?.parts?.[0]?.text || "";
                const movies = extractMoviesFromGeminiResponse(text);

                if (!movies || !Array.isArray(movies) || movies.length === 0) {
                    throw new Error('No movies found or failed to parse AI response.');
                }

                const formattedResponse = await formatMovieData(movies);
                resultsDiv.innerHTML = formattedResponse;
                return;
            } catch (err) {
                lastError = err;
                if (!err.message.toLowerCase().includes('overloaded')) break;
            }
        }
        throw lastError || new Error('Failed to get recommendations after several attempts.');
    } catch (error) {
        handleError(error);
    } finally {
        loader.style.display = 'none';
        document.getElementById('user-input').value = '';
    }
}

// Helper to extract JSON array from Gemini's response
function extractMoviesFromGeminiResponse(text) {
    // Try to find the first JSON array in the response
    const match = text.match(/\[\s*{[\s\S]*?}\s*\]/);
    if (!match) return null;
    try {
        return JSON.parse(match[0]);
    } catch (e) {
        return null;
    }
}

// Format Movie Data for Display (updated for new fields)
async function formatMovieData(movies) {
    let html = '';

    // Helper to fetch poster from OMDb if missing
    async function fetchPosterFromOMDb(movieName) {
        const url = `https://www.omdbapi.com/?t=${encodeURIComponent(movieName)}&apikey=${OMDB_API_KEY}`;
        try {
            const response = await fetch(url);
            const data = await response.json();
            if (data.Poster && data.Poster !== 'N/A') {
                return data.Poster;
            }
        } catch (e) {}
        return 'https://via.placeholder.com/300x450?text=Poster+Not+Found';
    }

    // Build all cards in parallel
    const cards = await Promise.all(movies.map(async (movie, index) => {
        let posterUrl = await fetchPosterFromOMDb(movie.name);

        return `
            <div class="movie-card">
                <h3>${index + 1}. ${movie.name || 'Unknown Movie'}</h3>
                <img class="movie-poster" src="${posterUrl}" alt="${movie.name || 'Movie Poster'}" style="max-width: 100%; border-radius: 8px; margin: 1rem 0;">
                <p>
                    <a href="${movie.trailer || '#'}" target="_blank" style="color: #e50914; text-decoration: underline;">Watch Trailer</a>
                </p>
            </div>
        `;
    }));

    return cards.join('');
}

// Session Management
function checkExistingSession() {
    const users = JSON.parse(localStorage.getItem('users')) || {};
    const lastUser = localStorage.getItem('lastUser');
    
    if (lastUser && users[lastUser]) {
        currentUser = lastUser;
        document.getElementById('auth-container').style.display = 'none';
        document.getElementById('main-app').style.display = 'block';
        return true;
    }
    return false;
}

// Logout Function
function logout() {
    currentUser = null;
    localStorage.removeItem('lastUser');
    document.getElementById('auth-container').style.display = 'block';
    document.getElementById('main-app').style.display = 'none';
    showLogin();
}

// Updated Window Load Handler
window.onload = async () => {
    if (!checkExistingSession()) {
        const users = JSON.parse(localStorage.getItem('users')) || {};
        if (Object.keys(users).length === 0) {
            showSignup();
        } else {
            showLogin();
        }
    }

    // Attach event listeners
    document.getElementById('logout-btn')?.addEventListener('click', logout);
    document.getElementById('get-recommendations-btn')?.addEventListener('click', getRecommendations);
    document.getElementById('signup-btn')?.addEventListener('click', showSignup);
    document.getElementById('login-btn')?.addEventListener('click', showLogin);
};

// Enhanced Login Function
function login() {
    const username = document.getElementById('login-username').value.trim();
    const password = document.getElementById('login-password').value;

    if (!username || !password) {
        alert('Please enter both username and password');
        return;
    }

    const users = JSON.parse(localStorage.getItem('users')) || {};
    
    if (!users[username] || users[username].password !== password) {
        alert('Invalid credentials!');
        return;
    }

    currentUser = username;
    localStorage.setItem('lastUser', username);
    document.getElementById('auth-container').style.display = 'none';
    document.getElementById('main-app').style.display = 'block';
}